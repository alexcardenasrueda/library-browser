package com.unir.librarybrowser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryBrowserApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryBrowserApplication.class, args);
	}

}
