package com.unir.librarybrowser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryBrowserApplicationTests {

	@Test
	void contextLoads() {
	}

}
